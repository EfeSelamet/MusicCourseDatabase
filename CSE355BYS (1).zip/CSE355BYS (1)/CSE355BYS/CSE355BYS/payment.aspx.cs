﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Web.UI.WebControls;

namespace CSE355BYS
{
    public partial class payment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGridView();
                TextBoxPayment.Visible = false;
                TextBoxContract.Visible = false;
                btnPay.Visible = false;
                lblMessage1.Visible = false;
                lblMessage2.Visible = false;
            }
        }

        private void BindGridView()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT PersonID 'Müşteri ID', FirstName 'İsim', LastName 'Soyisim', PhNumber 'Telefon Numarası' FROM Customer";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        GridView1.DataSource = dataTable;
                        GridView1.DataBind();
                    }
                }
            }
        }
        protected void btnContractLoad(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
            string CustomerID = txtCustID.Text;
            TextBoxPayment.Visible = true;
            TextBoxContract.Visible = true;
            btnPay.Visible = true;
            lblMessage1.Visible = true;
            lblMessage2.Visible = true;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Contract.ContractID 'Sözleşme Numarası', StartDate 'İmzalanma Tarihi', TotalAmount 'Ödeme Miktarı',"+
                    "NOfPayments 'Taksit Miktarı', isnull(SUM(payment.amount), 0) 'Yapılmış Ödeme' FROM Contract left join payment on payment.ContractID = Contract.ContractID where PersonID =@CustomerID"+
                    " GROUP BY Contract.ContractID, StartDate, TotalAmount, NOfPayments";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerID", CustomerID);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        GridView2.DataSource = dataTable;
                        GridView2.DataBind();
                    }
                }
            }
        }
        protected void btnPay_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
            String Contract = TextBoxContract.Text;
            String Payment = TextBoxPayment.Text;
            try { int.Parse(Payment); }
            catch (Exception ex)
            {
                Label2.Text = "Ödeme miktarı rakam olmalıdır.";
                Label2.ForeColor = System.Drawing.Color.Red;
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {

                    // SQL command to insert a new parent
                    string insertQuery = "exec AddPayment  @Amount, @ContractID";
                    SqlCommand insertCmd = new SqlCommand(insertQuery, con);
                    insertCmd.Parameters.AddWithValue("@Amount", Payment);
                    insertCmd.Parameters.AddWithValue("@ContractID", Contract);

                    con.Open();
                    int rowsAffected = insertCmd.ExecuteNonQuery();
                    con.Close();

                    if (rowsAffected > 0)
                    {
                        Label2.Text = "Başarıyla Ödeme Yapıldı.";
                        Label2.ForeColor = System.Drawing.Color.Green;
                    }
                    else
                    {
                        Label2.Text = "Ödeme yapılırken bir hata oluştu.";
                        Label2.ForeColor = System.Drawing.Color.Red;
                    }
                }
                catch (Exception ex)
                {
                    Label2.Text = "Hata: " + ex.Message;
                    Label2.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}
