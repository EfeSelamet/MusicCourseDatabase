﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace CSE355BYS
{
    public partial class addCourseSection : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CoursesDropDown();
                showInstructors();
            }
        }

        private void CoursesDropDown()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
            string sqlCourses = "SELECT Name FROM Course";


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sqlCourses, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlCourses.Items.Clear();

                    ddlCourses.Items.Add(new ListItem("Kurslar", ""));

                    while (reader.Read())
                    {
                        ListItem item = new ListItem(reader["Name"].ToString());
                        ddlCourses.Items.Add(item);
                    }
                    con.Close();
                }
            }
        }


        private void showInstructors()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ToString();

            SqlConnection con = new SqlConnection(connectionString);


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sqlstr = "select InstructorID as 'Öğretmen Numarası', FirstName + ' ' + LastName as Öğretmen, Specializations as Alanı from InstructorDetails";

                using (SqlCommand command = new SqlCommand(sqlstr, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        GridView1.DataSource = dataTable;
                        GridView1.DataBind();
                    }
                }
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;

            string Day = DayTextBox.Text;
            string Hour = HourTextBox.Text;
            string Classroom = ClassroomTextBox.Text;
            string Course = ddlCourses.Text;
            string AgeGroup = ddlAgeGroup.Text;


            string Instructor = InstructorTextBox.Text;


            if (string.IsNullOrEmpty(Day) || string.IsNullOrEmpty(Hour) || string.IsNullOrEmpty(Classroom) || string.IsNullOrEmpty(Course) || string.IsNullOrEmpty(AgeGroup) || string.IsNullOrEmpty(Instructor))
            {
                Label1.Text = "Lütfen tüm alanları doldurun.";
                Label1.ForeColor = System.Drawing.Color.Red;
                return;
            }


            string query = string.Format("exec addCourseSection '{0}', '{1}', '{2}', {3}, '{4}', '{5}', '{6}'", Day, Hour, Classroom, Instructor, Course, AgeGroup);

            
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        Label1.Text = "Student added successfully!";
                    }
                    catch (Exception ex)
                    {
                        Label1.Text = ex.ToString();
                    }
                }
            }
        }
    }
}