﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Web.UI.WebControls;

namespace CSE355BYS
{
    public partial class student : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                PopulateParentsDropdown();
            }
        }

        private void PopulateParentsDropdown()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
            string sqlMom = "SELECT FirstName + ' ' + LastName + ' ' + PhNumber as Person, PersonID FROM allFemaleParentsIDNameSurname";
            string sqlDad = "SELECT FirstName + ' ' + LastName + ' ' + PhNumber as Person, PersonID FROM allMaleParentsIDNameSurname";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sqlMom, con))
                {   
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlMom.Items.Clear();

                    ddlMom.Items.Add(new ListItem("Anne", ""));

                    while (reader.Read())
                    {
                        ListItem item = new ListItem(reader["Person"].ToString(), reader["PersonID"].ToString());
                        ddlMom.Items.Add(item);
                    }
                    con.Close();
                }

                using (SqlCommand cmd = new SqlCommand(sqlDad, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlDad.Items.Clear();

                    ddlDad.Items.Add(new ListItem("Baba", ""));

                    while (reader.Read())
                    {
                        ListItem item = new ListItem(reader["Person"].ToString(), reader["PersonID"].ToString());
                        ddlDad.Items.Add(item);
                    }
                }

            }
            
        }



        protected void btnAddStudent_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
            string fname = TextBox1.Text;
            string lname = TextBox2.Text;
            string phoneNumber = txtPhoneNumber.Text;
            string EducationLevel = ddlEducationLevel.Text;
            string adress = txtAddress.Text;
            string bDate = txtBirthDate.Text;
            string gender = rblGender.Text;
            string mom = ddlMom.Text;
            string dad = ddlDad.Text;


            if (string.IsNullOrEmpty(fname) || string.IsNullOrEmpty(lname) || string.IsNullOrEmpty(adress) ||string.IsNullOrEmpty(bDate))
            {
                Label1.Text = "Lütfen tüm alanları doldurun.";
                Label1.ForeColor = System.Drawing.Color.Red;
                return;
            }

            if (mom.Equals(""))
            {
                mom = "null";
            }
            if (dad.Equals(""))
            {
                dad = "null";
            }

            string query = string.Format("exec insertStudent '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', {7}, {8}", fname, lname, phoneNumber, EducationLevel, adress, bDate, gender, mom, dad);

            
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        Label1.Text = "Student added successfully!";
                    }
                    catch (Exception ex)
                    {
                        Label1.Text = ex.ToString();
                    }
                }
            }
        }
    }
}
