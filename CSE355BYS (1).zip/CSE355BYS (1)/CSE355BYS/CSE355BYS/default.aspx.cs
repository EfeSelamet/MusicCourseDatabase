﻿using System;
using System.Web.UI;

namespace CSE355BYS
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Any initialization logic for the home page can go here
        }

        protected void btnAddParent_Click(object sender, EventArgs e)
        {
            Response.Redirect("addParent.aspx"); // Redirect to Add Parent screen
        }

        protected void btnAddStudent_Click(object sender, EventArgs e)
        {
            Response.Redirect("student.aspx"); // Redirect to Add Student screen
        }

        protected void btnViewStudents_Click(object sender, EventArgs e)
        {
            //Response.Redirect("viewStudents.aspx"); // Redirect to View Students screen
        }
        protected void btnAddCourse_Click(object sender, EventArgs e)
        {
            Response.Redirect("addCourse.aspx"); // Redirect to View Students screen
        }
        protected void btnAddCourseSection_Click(object sender, EventArgs e)
        {
            Response.Redirect("addCourseSection.aspx"); // Redirect to View Students screen
        }

        protected void btnOrderEquipment_Click(object sender, EventArgs e)
        {
            Response.Redirect("orderEquipment.aspx"); // Redirect to View Students screen
        }

        protected void btnPayment_Click(object sender, EventArgs e)
        {
            Response.Redirect("payment.aspx"); // Redirect to View Students screen
        }

        protected void btnAddStudentToCourse_Click(object sender, EventArgs e)
        {
            Response.Redirect("addStudentToCourse.aspx"); // Redirect to View Students screen
        }

        protected void btnRemoveStudent_Click(object sender, EventArgs e)
        {
            Response.Redirect("removeStudent.aspx"); // Redirect to View Students screen
        }

        protected void btnAddContract_Click(object sender, EventArgs e)
        {
            Response.Redirect("addContract.aspx"); // Redirect to View Students screen
        }
    }
}
