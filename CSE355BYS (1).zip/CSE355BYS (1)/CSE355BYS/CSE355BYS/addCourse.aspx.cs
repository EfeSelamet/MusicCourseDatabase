﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace CSE355BYS
{
    public partial class addCourse : System.Web.UI.Page
    {
        protected void btnAddCourse_Click(object sender, EventArgs e)
        {
            // Retrieve input values
            string courseName = txtCourseName.Text.Trim();
            int minStudents;
            int maxStudents;
            int minAge;

            if (!int.TryParse(txtMinStudent.Text.Trim(), out minStudents))
            {
                lblMessage.Text = "Lütfen geçerli bir minimum öğrenci sayısı giriniz.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            if (!int.TryParse(txtMaxStudent.Text.Trim(), out maxStudents))
            {
                lblMessage.Text = "Lütfen geçerli maksimum öğrenci sayısı giriniz.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            if (!int.TryParse(txtMinAge.Text.Trim(), out minAge))
            {
                lblMessage.Text = "Lütfen geçerli bir minimum yaşı giriniz.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            // SQL query to insert course into the database
            string sqlQuery = "exec addCourse @Name, @MinStudents, @MaxStudents, @MinAge ";

            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conStr"].ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sqlQuery, con))
                {
                    // Add parameters to prevent SQL injection
                    cmd.Parameters.AddWithValue("@Name", courseName);
                    cmd.Parameters.AddWithValue("@MinStudents", minStudents);
                    cmd.Parameters.AddWithValue("@MaxStudents", maxStudents);
                    cmd.Parameters.AddWithValue("@minAge", minAge);
                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                        lblMessage.Text = "Course added successfully!";
                        lblMessage.ForeColor = System.Drawing.Color.Green;

                        // Clear input fields after successful insertion
                        txtCourseName.Text = string.Empty;
                        txtMinStudent.Text = string.Empty;
                        txtMaxStudent.Text = string.Empty;
                        txtMinAge.Text = string.Empty;
                    }
                    catch (Exception ex)
                    {
                        lblMessage.Text = "Error: " + ex.Message;
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                    }
                }
            }
        }
    }
}
