﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// 
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


namespace CSE355BYS
{
    public partial class stdRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["StdName"] = TextBox1.Text;
            Session["StdLastName"] = TextBox2.Text;
            Session["StdPhoneNumber"] = TextBox3.Text;
            Session["StdEducation"] = DropDownList1.SelectedValue;
            Session["StdAdress"] = TextBox4.Text;
            Session["StdBirthDate"] = TextBox5.Text;

            Console.WriteLine(Session["StdBirthDate"]);
            int year = Int32.Parse(TextBox5.Text.Split('-')[0]);

            int currentYear = DateTime.Now.Year;
            int age = currentYear - year;

            if (age < 18)
            {
                Response.Redirect("addParent.aspx");  
            }
            else
            {
                Response.Redirect("department.aspx");
            }
        }
    }
}