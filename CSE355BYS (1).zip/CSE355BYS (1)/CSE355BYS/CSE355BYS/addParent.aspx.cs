﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace CSE355BYS
{
    public partial class addParent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Optional: Any logic to handle on page load
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            // Retrieve form values
            string firstName = TextBox1.Text.Trim();
            string lastName = TextBox2.Text.Trim();
            string phoneNumber = TextBox3.Text.Trim();
            string educationLevel = DropDownList1.SelectedValue;
            string address = TextBox4.Text.Trim();
            string gender = rblGender.Text.Trim();

            // Validate inputs (basic validation for empty fields)
            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) ||string.IsNullOrEmpty(phoneNumber) || string.IsNullOrEmpty(address))
            {
                lblMessage.Text = "Lütfen tüm alanları doldurun.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            // Database connection
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    // SQL command to check if the parent already exists
                    string checkQuery = "SELECT COUNT(*) FROM Customer WHERE FirstName = @FirstName AND LastName = @LastName AND PhNumber = @PhoneNumber";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, con);
                    checkCmd.Parameters.AddWithValue("@FirstName", firstName);
                    checkCmd.Parameters.AddWithValue("@LastName", lastName);
                    checkCmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber);

                    con.Open();
                    int count = (int)checkCmd.ExecuteScalar();
                    con.Close();

                    if (count > 0)
                    {
                        lblMessage.Text = "Bu veli zaten mevcut.";
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                        return;
                    }

                    // SQL command to insert a new parent
                    string insertQuery = "exec insertParent  @FirstName, @LastName, @PhoneNumber, @EducationLevel, @Address, @Gender";
                    SqlCommand insertCmd = new SqlCommand(insertQuery, con);
                    insertCmd.Parameters.AddWithValue("@FirstName", firstName);
                    insertCmd.Parameters.AddWithValue("@LastName", lastName);
                    insertCmd.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                    insertCmd.Parameters.AddWithValue("@EducationLevel", educationLevel);
                    insertCmd.Parameters.AddWithValue("@Address", address);
                    insertCmd.Parameters.AddWithValue("@Gender", gender);

                    con.Open();
                    int rowsAffected = insertCmd.ExecuteNonQuery();
                    con.Close();

                    if (rowsAffected > 0)
                    {
                        lblMessage.Text = "Veli başarıyla eklendi.";
                        lblMessage.ForeColor = System.Drawing.Color.Green;

                        // Optionally clear form fields after successful addition
                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        TextBox3.Text = "";
                        DropDownList1.SelectedIndex = 0;
                        TextBox4.Text = "";
                        rblGender.Text = "";
                    }
                    else
                    {
                        lblMessage.Text = "Veli eklenirken bir hata oluştu.";
                        lblMessage.ForeColor = System.Drawing.Color.Red;
                    }
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "Hata: " + ex.Message;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}
