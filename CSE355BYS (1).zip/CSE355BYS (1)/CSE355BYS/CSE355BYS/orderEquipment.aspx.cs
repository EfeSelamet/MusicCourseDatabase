﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Web.UI.WebControls;

namespace CSE355BYS
{
    public partial class orderEquipment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGridView();
            }
        }

        private void BindGridView()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT EquipmentID, Type, Model, Price, CompanyName FROM Equipment";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        GridView1.DataSource = dataTable;
                        GridView1.DataBind();
                    }
                }
            }
        }

        protected void btnNextScreen_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;

            string EqId = txtEqID.Text;
            Session["EqId"] = EqId;
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    // SQL command to check if the parent already exists
                    string checkQuery = "SELECT COUNT(*) FROM Equipment WHERE EquipmentID = @EquipmentID";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, con);
                    checkCmd.Parameters.AddWithValue("@EquipmentID", EqId);

                    con.Open();
                    int count = (int)checkCmd.ExecuteScalar();
                    con.Close();

                    if (count < 1)
                    {
                        Label1.Text = "Ekipman Mevcut değil.";
                        Label1.ForeColor = System.Drawing.Color.Red;
                        return;
                    }
                    Response.Redirect("orderEquipmentCustomer.aspx");
                }
                catch (Exception ex)
                {
                    Label1.Text = "Hata: " + ex.Message;
                    Label1.ForeColor = System.Drawing.Color.Red;
                }
            }

        }
    }
}
