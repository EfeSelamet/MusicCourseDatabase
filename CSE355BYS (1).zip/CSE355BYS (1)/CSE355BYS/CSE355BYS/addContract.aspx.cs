﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Net;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace CSE355BYS
{
    public partial class addContract : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGridView();
            }
        }

        private void BindGridView()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT PersonID 'Müşteri ID', FirstName 'İsim', LastName 'Soyisim', PhNumber 'Telefon Numarası' FROM Customer";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        GridView1.DataSource = dataTable;
                        GridView1.DataBind();
                    }
                }
            }
        }

        protected void btnNextScreen_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;

            String TotalPayment = txtTotalPayment.Text;
            String CustId = txtCustID.Text;
            String NumOfPayments = txtNumOfPayments.Text;
            try { int.Parse(NumOfPayments); }
            catch (Exception ex)
            {
                Label1.Text = "Ödeme sayısı sayı olmalıdır.";
                Label1.ForeColor = System.Drawing.Color.Red;
                return;
            }
            try { int.Parse(TotalPayment); }
            catch (Exception ex)
            {
                Label1.Text = "Toplam ödeme miktarı sayı olmalıdır.";
                Label1.ForeColor = System.Drawing.Color.Red;
                return;
            }
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    // SQL command to check if the parent already exists
                    string checkQuery = "SELECT COUNT(*) FROM Customer WHERE PersonID = @PersonID";
                    SqlCommand checkCmd = new SqlCommand(checkQuery, con);
                    checkCmd.Parameters.AddWithValue("@PersonID", CustId);

                    con.Open();
                    int count = (int)checkCmd.ExecuteScalar();
                    con.Close();

                    if (count < 1)
                    {
                        Label1.Text = "Müşteri Mevcut değil.";
                        Label1.ForeColor = System.Drawing.Color.Red;
                        return;
                    }

                    // SQL command to insert a new parent
                    string insertQuery = "insert into Contract(StartDate, TotalAmount, NOfPayments, PersonID) "+
                        "values (getdate(), @TotalAmount, @NOfPayments, @PersonID)";
                    SqlCommand insertCmd = new SqlCommand(insertQuery, con);
                    insertCmd.Parameters.AddWithValue("@TotalAmount", TotalPayment);
                    insertCmd.Parameters.AddWithValue("@PersonID", CustId);
                    insertCmd.Parameters.AddWithValue("@NOfPayments", NumOfPayments);

                    con.Open();
                    int rowsAffected = insertCmd.ExecuteNonQuery();
                    con.Close();

                    if (rowsAffected > 0)
                    {
                        Label1.Text = "Sözleşme Başarıyla Eklendi.";
                        Label1.ForeColor = System.Drawing.Color.Green;
                    }
                    else
                    {
                        Label1.Text = "Sözleşme Eklenirken Bir Hata Oluştu.";
                        Label1.ForeColor = System.Drawing.Color.Red;
                    }
                }
                catch (Exception ex)
                {
                    Label1.Text = "Hata: " + ex.Message;
                    Label1.ForeColor = System.Drawing.Color.Red;
                }
            }
        }


    }
}
