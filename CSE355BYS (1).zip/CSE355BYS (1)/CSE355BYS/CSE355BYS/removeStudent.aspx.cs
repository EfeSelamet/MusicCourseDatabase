﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CSE355BYS
{
    public partial class removeStudent : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadStudents();
            }
        }

        private void LoadStudents()
        {
            string query = "SELECT S.PersonID as 'Öğrenci Numarası', C.FirstName + ' ' + C.LastName AS Öğrenci FROM Student S inner join Customer C on S.PersonId = C.PersonID";
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlStudents.Items.Clear();

                    ddlStudents.Items.Add(new ListItem("Öğrenci", ""));

                    while (reader.Read())
                    {
                        ListItem item = new ListItem(reader["Öğrenci Numarası"].ToString() + ' ' + reader["Öğrenci"].ToString());
                        ddlStudents.Items.Add(item);
                    }
                    con.Close();
                }
            }
        }


        protected void btnAdd_Click(object sender, EventArgs e)
        {
            
            int studentID;

            if (!int.TryParse(ddlStudents.Text.Split()[0], out studentID))
            {
                lblMessage.Text = "Lütfen öğrenci şeçiniz.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }


            string query = "exec RemoveStudentFromSystem @StudentID";
            string constr = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;

            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        cmd.Parameters.AddWithValue("@StudentID", studentID);
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }

                    catch (Exception ex)
                    {
                        lblMessage.Text = ex.Message;
                    }
                }
            }

            lblMessage.Text = "Öğrenci başarıyla Sistemden silindi!";
            lblMessage.ForeColor = System.Drawing.Color.Green;
        }
    }
}
