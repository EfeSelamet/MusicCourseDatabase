﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CSE355BYS
{
    public partial class addStudentToCourse : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadStudents();
                LoadCourseSections();
            }
        }

        private void LoadStudents()
        {
            string query = "SELECT S.PersonID as 'Öğrenci Numarası', C.FirstName + ' ' + C.LastName AS Öğrenci FROM Student S inner join Customer C on S.PersonId = C.PersonID";
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlStudents.Items.Clear();

                    ddlStudents.Items.Add(new ListItem("Öğrenci", ""));

                    while (reader.Read())
                    {
                        ListItem item = new ListItem(reader["Öğrenci Numarası"].ToString() + ' ' + reader["Öğrenci"].ToString());
                        ddlStudents.Items.Add(item);
                    }
                    con.Close();
                }
            }
        }

        private void LoadCourseSections()
        {
                
            string connectionString = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;
            string query = "SELECT SectionID, CourseName , CONVERT(VARCHAR, Date, 103) + ' ' + CONVERT(VARCHAR, Time, 120) AS Dersler FROM CourseSection";


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlCourseSections.Items.Clear();

                    ddlCourseSections.Items.Add(new ListItem("Dersler", "CourseName"));

                    while (reader.Read())
                    {
                        ListItem item = new ListItem(reader["SectionID"].ToString() + ' ' + reader["CourseName"].ToString() + ' ' +reader["Dersler"].ToString());
                        ddlCourseSections.Items.Add(item);
                    }
                    con.Close();
                }
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            
            int studentID;
            int sectionID;

            if (!int.TryParse(ddlStudents.Text.Split()[0], out studentID))
            {
                lblMessage.Text = "Lütfen öğrenci şeçiniz.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            if (!int.TryParse(ddlCourseSections.Text.Split()[0], out sectionID))
            {
                lblMessage.Text = "Lütfen Ders seçiniz.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }


            string query = "exec studentEnrollCourse @StudentID, @SectionID";
            string constr = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;

            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    try
                    {
                        cmd.Parameters.AddWithValue("@StudentID", studentID);
                        cmd.Parameters.AddWithValue("@SectionID", sectionID);
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }

                    catch (Exception ex)
                    {
                        lblMessage.Text = ex.Message;
                    }
                }
            }

            lblMessage.Text = "Öğrenci başarıyla kursa eklendi!";
            lblMessage.ForeColor = System.Drawing.Color.Green;
        }
    }
}
